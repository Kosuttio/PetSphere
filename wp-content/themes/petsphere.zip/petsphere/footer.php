<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> PetSphere. Všechna práva vyhrazena.</p>
        <p style="font-size: 0.8rem; color: #aaa;">Powered by Microsoft Azure & AI Technology.</p>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
